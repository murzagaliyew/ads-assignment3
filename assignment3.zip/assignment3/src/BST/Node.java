package BST;

public class Node {

    int value;
    Node leftChild;
    Node rightChild;

    public Node(int value, Node left, Node right){
        this.value = value;
        this.leftChild = left;
        this.rightChild = right;
    }
}
